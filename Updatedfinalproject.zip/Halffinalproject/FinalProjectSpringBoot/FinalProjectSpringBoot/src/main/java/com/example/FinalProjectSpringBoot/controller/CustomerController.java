package com.example.FinalProjectSpringBoot.controller;

//Controller file
//we only create the file(EmployeeController.java)
import com.example.FinalProjectSpringBoot.entity.Customer;
import com.example.FinalProjectSpringBoot.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
//@CrossOrigin(origins="http://localhost:4200")
public class CustomerController {

  @Autowired
  private CustomerService customerService;
  @PostMapping("/customers")
  public Customer saveCustomer(@RequestBody Customer customer) {
      return customerService.saveCustomer(customer);
  }
  @GetMapping("/customers")
  public List<Customer> getAllCustomers() {
      return customerService.fetchAllCustomers();
  }
  @GetMapping("/customers/{id}")
  public Customer getCustomerById(@PathVariable("id") Long id) {
      return customerService.getCustomerById(id);
  }

  @PutMapping("/customers/{id}")
  public Customer updateCustomer(@PathVariable("id") Long id, @RequestBody Customer customer) {
      return customerService.updateCustomerById(id, customer);
  }
  @DeleteMapping("/customers/{id}")
  public String deleteCustomer(@PathVariable("id") Long id) {
      return customerService.deleteDepartmentById(id);
  }
}

